package com.eliorcohen123456.locationprojectroom.DataAppPackage;

import java.io.Serializable;

class OpeningHours implements Serializable {

    private boolean open_now;
}
