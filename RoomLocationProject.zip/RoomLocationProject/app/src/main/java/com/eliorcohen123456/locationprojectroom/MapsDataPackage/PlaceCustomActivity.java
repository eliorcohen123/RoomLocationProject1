package com.eliorcohen123456.locationprojectroom.MapsDataPackage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.eliorcohen123456.locationprojectroom.R;

// Activity of CustomFragment
public class PlaceCustomActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_custom_fragment);

  }

}
